var express = require("express");
var router = express.Router();

/* GET home page. */
router.get("/", function (req, res, next) {
  let operations = [];
  // if (req.cookies.operations) operations = req.cookies.operations;
  if (req.session.calulations) operations = req.session.calulations;
  res.render("calculator", { title: "Calculaor", operations });
});

router.post("/calculate", function (req, res, next) {
  console.log(req.body);
  let result = calculate(
    parseInt(req.body["op-1"]),
    parseInt(req.body["op-2"]),
    req.body.operation
  );
  console.log(`Result:${result}`);
  let operations = [];

  // Using Cookie
  /* if (req.cookies.calulations) {
    operations = req.cookies.calulations;
  } */

  // Using Session
  if (req.session.calulations) {
    operations = req.session.calulations;
  }

  let operation = {
    op1: req.body["op-1"],
    op2: req.body["op-2"],
    operation: req.body.operation,
    result: result,
  };
  operations.push(operation);
  // res.cookie("calulations", operations);
  req.session.calulations = operations;

  res.render("calculator", { title: "Calculaor", operations });
});
function calculate(op1, op2, operation) {
  if (operation == "+") {
    return op1 + op2;
  } else if (operation == "-") {
    return op1 - op2;
  } else if (operation == "*") {
    return op1 * op2;
  } else if (operation == "/") {
    if (op2 == 0) {
      return "Invalid Operation";
    } else {
      return op1 / op2;
    }
  }
}

module.exports = router;
