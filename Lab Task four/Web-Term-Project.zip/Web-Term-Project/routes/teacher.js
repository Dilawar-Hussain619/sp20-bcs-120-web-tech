var express = require("express");
var router = express.Router();
const Questionnaire = require("../models/questionnaire");
const authMiddleware = require("../middleware/teacherAuth");

router.get("/", authMiddleware, (req, res) => {
  res.redirect("/teacher/all-questionnaire");
});

router.get("/new-questionnaire", authMiddleware, (req, res) => {
  res.render("teacher-new");
});

router.post("/create-new-questionnaire", authMiddleware, async (req, res) => {
  try {
    const { title, questions } = req.body;
    console.log(req.body);

    const createdBy = req.session.user.username;

    const newQuestionnaire = new Questionnaire({
      title,
      questions,
      createdBy,
    });

    const savedQuestionnaire = await newQuestionnaire.save();

    res.redirect("/teacher/new-questionnaire");
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.get("/all-questionnaire", authMiddleware, async (req, res) => {
  try {
    const questionnaires = await Questionnaire.find();

    res.render("teacher-all-questionnaire", { questionnaires });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Display the edit form for a specific questionnaire
router.get("/all-questionnaires/:id/edit", authMiddleware, async (req, res) => {
  try {
    const questionnaire = await Questionnaire.findById(req.params.id);

    if (!questionnaire) {
      return res.status(404).json({ error: "Questionnaire not found" });
    }

    res.render("teacher-edit-questionnaire", { questionnaire });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Update a specific questionnaire
router.post("/update", authMiddleware, async (req, res) => {
  try {
    const { title, questions, id } = req.body;

    const updatedQuestionnaire = await Questionnaire.findByIdAndUpdate(
      id,
      { title, questions },
      { new: true }
    );

    if (!updatedQuestionnaire) {
      return res.status(404).json({ error: "Questionnaire not found" });
    }

    res.redirect("/teacher/all-questionnaire");
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.get("/questionnaire/delete/:id", async (req, res) => {
  try {
    const deletedQuestionnaire = await Questionnaire.findByIdAndDelete(
      req.params.id
    );

    res.redirect("/teacher/all-questionnaire");
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
