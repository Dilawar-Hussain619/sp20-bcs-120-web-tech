var express = require("express");
var router = express.Router();
const User = require("../models/user");

router.get("/", async (req, res) => {
  try {
    // Check if the user is already logged in
    if (req.session.user) {
      // Redirect to the respective dashboard based on user role
      if (req.session.user.role === "teacher") {
        return res.redirect("/teacher");
      } else if (req.session.user.role === "student") {
        return res.redirect("/student");
      }
    }

    // User is not logged in, render the login page
    res.render("login");
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { username, password } = req.body;

    // Check if the user exists in the database
    const user = await User.findOne({ username, password });

    if (!user) {
      const errorMessage = "Invalid credentials";
      return res.render("login", { error: errorMessage });
    }

    // Save the logged-in user in the session
    req.session.user = {
      id: user._id,
      username: user.username,
      role: user.role,
    };

    // Redirect based on user role
    if (user.role === "teacher") {
      res.redirect("/teacher");
    } else if (user.role === "student") {
      res.redirect("/student");
    } else {
      return res.render("login", { error: "Invalid user role" });
    }
  } catch (error) {
    console.error(error);
    res.render("login", { error: "Internal Server Error" });
  }
});

// Register endpoint
router.post("/register", async (req, res) => {
  try {
    const { name, username, password, role } = req.body;

    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ error: "Username is already taken" });
    }

    // Create a new user
    const newUser = new User({
      name,
      username,
      password,
      role,
    });

    // Save the new user to the database
    const savedUser = await newUser.save();

    res.status(201).json(savedUser);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

// Logout endpoint
router.get("/logout", (req, res) => {
  // Destroy the session
  req.session.destroy((err) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ error: "Logout failed" });
    }

    // Redirect to the login page after successful logout
    res.redirect("/user");
  });
});

module.exports = router;
