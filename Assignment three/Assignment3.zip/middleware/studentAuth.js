const authMiddleware = (req, res, next) => {
  // Check if the user is logged in
  if (!req.session.user) {
    return res.redirect("/user"); // Redirect to login if not logged in
  }

  // Check the user's role
  const userRole = req.session.user.role;

  // Allow access to /student only for users with the role 'student'
  if (userRole !== "student") {
    return res.status(403).send("Forbidden"); // Return a 403 Forbidden response
  }

  res.locals.user = req.session.user;
  // If the user has the correct role, proceed to the next middleware or route handler
  next();
};

module.exports = authMiddleware;
