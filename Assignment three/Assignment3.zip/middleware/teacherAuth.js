const authMiddleware = (req, res, next) => {
  // Check if the user is logged in
  if (!req.session.user) {
    return res.redirect("/user"); // Redirect to login if not logged in
  }

  // Check the user's role
  const userRole = req.session.user.role;

  // Allow access to /teacher only for users with the role 'teacher'
  if (userRole !== "teacher") {
    return res.status(403).send("Forbidden");
  }

  res.locals.user = req.session.user;
  // If the user has the correct role, proceed to the next middleware or route handler
  next();
};

module.exports = authMiddleware;
