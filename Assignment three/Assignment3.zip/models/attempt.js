const mongoose = require("mongoose");

const attemptSchema = new mongoose.Schema({
  questionnaire: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Questionnaire",
    required: true,
  },
  student: {
    type: String,
    ref: "User.username",
    required: true,
  },
  answers: [
    {
      question: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Questionnaire.questions",
        required: true,
      },
      selectedOption: {
        type: Number,
        required: true,
      },
      isCorrect: {
        type: Boolean,
        default: false,
      },
    },
  ],
  status: {
    type: String,
    enum: ["drafted", "submitted"],
    default: "drafted",
  },
});

const Attempt = mongoose.model("Attempt", attemptSchema);

module.exports = Attempt;
