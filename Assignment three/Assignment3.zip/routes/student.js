var express = require("express");
var router = express.Router();
const Attempt = require("../models/attempt");
const Questionnaire = require("../models/questionnaire");
const User = require("../models/user");

const authMiddleware = require("../middleware/studentAuth");

router.get("/", authMiddleware, (req, res) => {
  res.redirect("/student/new-questionnaire");
});

// Display all questionnaires that the student hasn't attempted yet
router.get("/new-questionnaire", authMiddleware, async (req, res) => {
  try {
    const studentUsername = req.session.user.username;

    // Get the IDs of questionnaires that the student has attempted
    const attemptedQuestionnaireIds = await Attempt.find({
      student: studentUsername,
    }).distinct("questionnaire");

    // Get all questionnaires that the student hasn't attempted yet
    const notAttemptedQuestionnaires = await Questionnaire.find({
      _id: { $nin: attemptedQuestionnaireIds },
    });

    res.render("notattempted", { notAttemptedQuestionnaires });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Internal Server Error" });
  }
});

module.exports = router;
